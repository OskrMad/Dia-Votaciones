# Aplicación Interactiva: Día de las Elecciones 2026

## Descripción General

Aplicación web moderna, completamente responsiva y 100% funcional para el **Día de las Elecciones 2026** del Colegio Técnico 1978. Replica exactamente el diseño visual del croquis original del campus y proporciona dos vistas independientes:

1. **Vista A: Mapa Interactivo Dinámico** - Croquis interactivo con pines de actividades y sistema avanzado de "Modo Lluvia"
2. **Vista B: Asignación de Aulas para Pertenencias** - Tabla interactiva de búsqueda rápida

---

## Características Principales

### ✨ Mapa Interactivo (Vista A)

- **Croquis Fiel al Original**: Replicación exacta del layout del campus con aulas, zonas comunes y espacios exteriores
- **Pines Dinámicos**: Todos los pines visibles en todo momento (18 ubicaciones diferentes)
- **Colores Identificadores**:
  - Azul: Aulas regulares
  - Púrpura/Magenta: Zona 1
  - Morado: Zona 3
  - Cian: Zona 4
  - Verde: Aula Ecológica
  - Naranja: Entrada Principal
  - Rosa: Multiusos

### 🌧️ Modo Lluvia Avanzado

Transición visual suave con reubicación geográfica en tiempo real:

- **Zona 1** → Pasillo enfrente del Comedor (Prof. Neidy Mairena)
- **Zona 3** → Rampa techada Entrada Principal (Profs. Castro, Jara, Navarrete, Sequeira)
- **Zona 4** → Pasillo Principal Techado (Profs. Argüello, Chacón)
- **Aula Ecológica** → Pasillo frente a Biblioteca (Prof. Gabriela Vásquez)
- **Entrada Principal** → Pasillo Administración (Profs. Agüero, Chinchilla)

**Indicadores Visuales**:
- Pines reubicados parpadean en naranja
- Banner de alerta explícito con información del traslado
- Interfaz oscurecida con tonalidades lluviosas

### 📊 Panel de Control Colapsable

**Menú Flotante/Sidebar (Show/Hide)**:
- Selector de sección (dropdown de 10-1 a 12-6)
- Botón Modo Lluvia con ícono de nube
- Timeline cronológica del horario de la sección seleccionada

**Responsividad**:
- En móviles: Panel flotante colapsable (botón flotante inferior)
- En desktop: Sidebar fijo a la izquierda
- Transiciones suaves al abrir/cerrar

### 📋 Asignación de Aulas (Vista B)

- **Búsqueda Interactiva**: Campo de búsqueda con filtrado en tiempo real
- **Tabla Completa**: Vista de todas las secciones y sus aulas asignadas
- **Detalle por Sección**: Al seleccionar una sección, muestra:
  - Sección
  - Aula asignada
  - Información importante
  - Visualización del layout de aulas

**Datos Integrados**:
```
10-1 → Aula 22 | 10-2 → Aula 3 | 10-3 → Aula 19 | 10-4 → Aula 15
10-5 y 10-6 → Aula 1
11-1 → Aula 2 | 11-2 → Aula 11 | 11-3 → Aula 13 | 11-4 → Aula 8
11-5 y 11-6 → Aula 24 | 11-7 → Aula 23
12-1 → Aula 5 | 12-2 → Aula 4 | 12-3 → Aula 21
12-4 y 12-5 → Aula 12 | 12-6 → Aula 10
```

---

## Cronograma Integrado

**Rango Horario**: 12:10 p.m. - 3:50 p.m.

**15 Estaciones por Sección**: Cada sección tiene su propio cronograma personalizado

**Datos Precisos**: Todos los 271 cronogramas (19 secciones × 15 actividades) cargados internamente desde archivos estáticos TypeScript

---

## Estructura del Proyecto

```
src/
├── App.tsx                 # Componente principal con navegación
├── components/
│   ├── MapView.tsx        # Vista del mapa con panel lateral
│   ├── InteractiveMap.tsx # SVG interactivo del croquis
│   ├── ScheduleTimeline.tsx  # Timeline de horarios
│   └── BelongingsView.tsx # Vista de asignación de aulas
├── data/
│   ├── schedules.ts       # Todos los cronogramas (19 secciones)
│   └── pins.ts            # Datos de pines y reubicaciones
├── index.css              # Estilos globales y animaciones
└── main.tsx               # Punto de entrada
```

---

## Diseño Visual

### Paleta de Colores
- **Fondos Principales**: Slate 900 (#0f172a)
- **Fondos Secundarios**: Slate 800 (#1e293b)
- **Primario**: Azul 600 (#2563eb)
- **Alerta/Lluvia**: Naranja 500 (#f97316)
- **Textos**: Slate 50, 100, 300
- **Bordes**: Slate 700 (#374151)

### Tipografía
- **Font Stack**: system-ui, -apple-system, sans-serif
- **Font Weights**: 400 (regular), 600 (semibold), 700 (bold)
- **Line Heights**: 150% body, 120% headings

### Animaciones
- **Transiciones**: 300ms ease-out
- **Parpadeo de Pines**: 2s cubic-bezier
- **Hover States**: Scale 1.05 con shadow
- **Mobile Panel**: Slide-in animation 300ms

---

## Responsividad

### Breakpoints
- **Mobile**: < 768px (max-width)
- **Tablet**: 768px - 1024px
- **Desktop**: > 1024px

### Optimizaciones Móviles
- Grid de secciones: 2 columnas en móvil, 6+ en desktop
- Panel colapsable con botón flotante
- Scroll horizontal en tablas si es necesario
- Touch-friendly buttons (min 44px)
- Reduced padding en móvil

---

## Cómo Usar la Aplicación

### Para Estudiantes

1. **En Vista de Mapa**:
   - Selecciona tu sección desde el panel lateral
   - Visualiza todas las actividades en orden cronológico
   - Si llueve, presiona "Modo Lluvia" para ver ubicaciones modificadas
   - Haz clic en cualquier pin para más detalles

2. **En Vista de Aulas**:
   - Busca tu sección en el campo de búsqueda
   - Haz clic en tu sección para ver dónde dejar tus bultos
   - Memoriza el aula asignada (por ej: Aula 22 para 10-1)

### Para Profesores

- Utiliza el mapa para coordinar movimientos de estudiantes
- En caso de lluvia, el "Modo Lluvia" muestra exactamente dónde se reasignan las actividades
- El timeline ayuda a sincronizar los cambios de grupo

---

## Animaciones y Transiciones

- **Pin Hover**: Scale + shadow
- **Mode Rain Toggle**: Color fade + border flash
- **Panel Open/Close**: Slide animation
- **Pin Relocation**: Smooth transition + pulsing effect
- **Button Hover**: Background color change + slight scale

---

## Características Técnicas

### Stack Tecnológico
- **React 18**: Framework frontend
- **TypeScript**: Tipado estático
- **Tailwind CSS**: Utility-first styling
- **Vite**: Build tool ultrarrápido
- **Lucide React**: Icon library

### Performance
- Build size: ~188 KB (gzipped: ~54 KB)
- Lazy loading de componentes
- Optimización de re-renders con React hooks
- CSS optimizado y purgado

### Compatibilidad
- Navegadores modernos (Chrome, Firefox, Safari, Edge)
- Soporte mobile completo (iOS, Android)
- Responsive Design Media Queries
- SVG para gráficos escalables

---

## Instrucciones de Despliegue

### Desarrollo Local
```bash
npm install
npm run dev
```

### Construcción para Producción
```bash
npm run build
```

El proyecto se compilará en la carpeta `dist/` lista para desplegar.

---

## Datos Incluidos

### 19 Secciones
10-1, 10-2, 10-3, 10-4, 10-5, 10-6, 11-1, 11-2, 11-3, 11-4, 11-5, 11-6, 11-7, 12-1, 12-2, 12-3, 12-4, 12-5, 12-6

### 18 Ubicaciones en Mapa
- 6 Aulas principales (32-37)
- 4 Zonas abiertas (1, 2, 3, 4)
- 2 Espacios especiales (Aula Ecológica, Multiusos)
- 2 Ubicaciones administrativas (Comedor, Entrada Principal)
- 2 Espacios deportivos (Gimnasio, otras áreas)

### 271 Actividades Totales
15 actividades × 19 secciones = 285 registros de cronograma

---

## Modo Lluvia: Lógica Detallada

Al presionar "Modo Lluvia":
1. Interfaz cambia a tonos oscuros/azulados
2. Pines de zonas abiertas se desplazan a ubicaciones techadas
3. Pines reubicados muestran indicador de parpadeo naranja
4. Click en pin reubicado muestra banner: "⚠️ TRASLADO POR LLUVIA"
5. Timeline muestra actividades reubicadas con color diferente

**Razonamiento de Reubicaciones**:
- Todas las zonas abiertas → Pasillos o espacios techados
- Aula Ecológica → Pasillo techado (protege equipo de sonido)
- Entrada Principal → Pasillo interior (evita ráfagas de viento/agua)

---

## Soporte y Contacto

Para actualizar datos o realizar cambios:
1. Edita archivos en `src/data/schedules.ts` y `src/data/pins.ts`
2. Ejecuta `npm run build` para compilar
3. Verifica en navegador antes de desplegar

---

## Versión
**v1.0.0** - Mayo 2026
**Última Actualización**: 29 de mayo de 2026

---

Esta aplicación fue desarrollada con atención al detalle, asegurando que cada aspecto del Día de las Elecciones 2026 sea accesible y fácil de navegar para estudiantes y profesores.
