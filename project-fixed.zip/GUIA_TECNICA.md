# Guía Técnica - Aplicación Día de las Elecciones 2026

## Descripción de Componentes

### 1. App.tsx (Componente Raíz)

**Responsabilidades:**
- Manejo de navegación entre vistas (Map vs Belongings)
- Gestión del estado global (sección seleccionada, modo lluvia)
- Header con navegación principal
- Mobile menu colapsable

**Props State:**
- `activeView`: 'map' | 'belongings'
- `isMenuOpen`: boolean (estado del menú móvil)
- `selectedSection`: string (sección actual, ej: '10-1')
- `isRainMode`: boolean (modo lluvia activo)

**Componentes Hijos:**
- MapView (cuando activeView === 'map')
- BelongingsView (cuando activeView === 'belongings')

---

### 2. MapView.tsx

**Responsabilidades:**
- Contenedor principal de la vista del mapa
- Manejo del panel lateral colapsable
- Coordinación entre InteractiveMap, ScheduleTimeline y selector de secciones

**Props:**
```typescript
interface MapViewProps {
  selectedSection: string;
  isRainMode: boolean;
  onSectionChange: (section: string) => void;
  onRainModeToggle: () => void;
  sections: string[];
  currentSchedule: Activity[];
}
```

**Layout:**
- Grid: 1 columna en móvil, 4 columnas en desktop
- Col 1: Panel Sidebar (1 columna)
  - Selector de secciones
  - Botón de Modo Lluvia
  - Timeline de cronograma
- Col 2-4: Contenedor del mapa (3 columnas)
  - InteractiveMap
  - Botón flotante para abrir/cerrar panel (solo móvil)

**Animaciones:**
- Panel abre con `animate-slide-in` en móvil
- Transición de colores al cambiar modo lluvia (300ms)

---

### 3. InteractiveMap.tsx

**Responsabilidades:**
- Renderizar SVG del croquis del campus
- Manejar clicks en pines
- Aplicar animaciones de reubicación en modo lluvia
- Mostrar detalles de pines seleccionados

**Estructura SVG:**
- ViewBox: 1200x800 (mantiene ratio)
- Elementos base: Rectángulos para aulas y zonas
- Elementos dinámicos: Círculos para pines con iconos

**Lógica de Pines:**
```typescript
// Para cada pin se calcula:
const x = isRainMode && pin.rainX !== undefined ? pin.rainX : pin.originalX;
const y = isRainMode && pin.rainY !== undefined ? pin.rainY : pin.originalY;
```

**Pines Reubicables (5 totales):**
1. Zona 1 (original: 420, 510 → lluvia: 420, 240)
2. Zona 3 (original: 600, 175 → lluvia: 750, 80)
3. Zona 4 (original: 250, 550 → lluvia: 500, 390)
4. Aula Ecológica (original: 995, 460 → lluvia: 850, 678)
5. Entrada Principal (original: 720, 650 → lluvia: 280, 550)

**Estilos:**
- Pines reubicados: Parpadean con `animation: pulse 2s infinite`
- Pines seleccionados: Scale +25% y shadow aumentada
- Colores según tipo de ubicación

---

### 4. ScheduleTimeline.tsx

**Responsabilidades:**
- Mostrar cronograma de la sección seleccionada
- Identificar actividades en zonas reubicables
- Diseño de lista scrolleable

**Props:**
```typescript
interface ScheduleTimelineProps {
  schedule: Activity[];
  isRainMode: boolean;
}
```

**Características:**
- Max height 96 (overflow-y-auto)
- Cada ítem muestra:
  - Número de estación (badge circular)
  - Nombre de actividad
  - Ubicación (con ícono de pin)
  - Hora (con ícono de reloj)
- Ítems en zonas reubicables: Fondo naranja en modo lluvia

---

### 5. BelongingsView.tsx

**Responsabilidades:**
- Vista de asignación de aulas para pertenencias
- Búsqueda interactiva de secciones
- Mostrar tabla y vista detallada

**Estado:**
- `searchTerm`: string (término de búsqueda)
- `selectedSection`: string | null (sección expandida)

**Datos:**
```typescript
const BELONGINGS_ASSIGNMENT: Record<string, string> = {
  '10-1': '22', '10-2': '3', ...
}
```

**Vistas:**
1. Grid de secciones (filtradas por búsqueda)
2. Vista detallada al seleccionar sección:
   - Información de sección y aula
   - Box informativo con instrucciones
   - Visualización del layout de aulas (grid 6 columnas)
3. Tabla completa si no se selecciona ninguna sección

---

## Estructuras de Datos

### Activity (Interfaz)
```typescript
interface Activity {
  station: number;           // 1-15
  activity: string;          // Nombre de la actividad
  place: string;            // Ubicación (Aula X, Zona Y)
  time: string;             // Hora formato "12:10 — 12:25"
}
```

### Section (Interfaz)
```typescript
interface Section {
  name: string;             // '10-1'
  schedule: Activity[];     // Array de 15 actividades
}
```

### PinLocation (Interfaz)
```typescript
interface PinLocation {
  id: string;               // Identificador único
  label: string;            // Nombre del pin
  icon: string;             // Emoji o icono
  originalX: number;        // Coordenada X original
  originalY: number;        // Coordenada Y original
  rainX?: number;           // Coordenada X en modo lluvia
  rainY?: number;           // Coordenada Y en modo lluvia
  color: string;            // Color hex
  details?: {               // Información de reubicación
    originalLocation: string;
    rainLocation: string;
    responsible: string;
    activities: string;
  };
}
```

---

## Flujo de Datos

### Vista Normal
```
App → selectedSection
   ├→ MapView
   │   ├→ InteractiveMap (muestra pines en posiciones originales)
   │   └→ ScheduleTimeline (muestra cronograma de sección)
   └→ [BelongingsView oculta]
```

### Vista Modo Lluvia
```
App → isRainMode = true
   ├→ MapView
   │   ├→ InteractiveMap (pines reubicables en nuevas posiciones, parpadean)
   │   └→ ScheduleTimeline (ítems reubicables con fondo naranja)
   └→ [color de interfaz cambia a tonos oscuros/azulados]
```

---

## Estilos y Temas

### Tailwind Configuration
- Modo oscuro por defecto (no usa `dark:` prefix)
- Colores base: slate (usado en toda la aplicación)
- Paleta ampliada: blue, orange, purple, cyan, green

### Variables CSS Personalizadas (en index.css)
- `@keyframes pulse` - Parpadeo de pines
- `@keyframes slideInFromLeft` - Animación del panel
- `@keyframes pinBounce` - Rebote de pines

### Breakpoints Utilizados
```typescript
// Mobile First
- Base: < 768px
- md: ≥ 768px (tablets)
- lg: ≥ 1024px (desktops)
```

---

## Cómo Agregar una Nueva Sección

1. **En `src/data/schedules.ts`:**
```typescript
export const SCHEDULES: Record<string, Section> = {
  // ... secciones existentes
  'XX-Y': {
    name: 'XX-Y',
    schedule: [
      { station: 1, activity: 'Actividad 1', place: 'Aula 32', time: '12:10 — 12:25' },
      // ... 14 actividades más
    ]
  }
};
```

2. **En `src/components/BelongingsView.tsx`:**
```typescript
const BELONGINGS_ASSIGNMENT: Record<string, string> = {
  // ... asignaciones existentes
  'XX-Y': 'AulaNumber',
};
```

3. El resto se actualiza automáticamente (dropdown, búsqueda, timeline)

---

## Cómo Agregar/Modificar Pines

1. **En `src/data/pins.ts`:**
```typescript
export const PIN_LOCATIONS: PinLocation[] = [
  // ... pines existentes
  {
    id: 'unique-id',
    label: 'Nueva Ubicación',
    icon: '🎯',
    originalX: 400,
    originalY: 300,
    rainX: 450,        // Solo si es reubicable
    rainY: 350,        // Solo si es reubicable
    color: '#3b82f6',
    details: {
      originalLocation: 'Ubicación Original',
      rainLocation: 'Ubicación en Lluvia',
      responsible: 'Profesor Responsable',
      activities: 'Actividad 1 / Actividad 2'
    }
  }
];
```

2. La aplicación automáticamente:
   - Renderiza el nuevo pin
   - Aplica animaciones en modo lluvia
   - Muestra detalles al hacer click

---

## Performance Optimization

### Técnicas Aplicadas
1. **Component Splitting**: Cada vista en su propio componente
2. **Memoization**: Uso de `useMemo` para cálculos en MapView
3. **SVG Optimization**: ViewBox escalable en lugar de imágenes
4. **CSS Optimization**: Tailwind purga clases no utilizadas
5. **Lazy Loading**: Componentes importados dinámicamente

### Bundle Size
```
dist/assets/index-*.css   ~4 KB (gzipped)
dist/assets/index-*.js    ~54 KB (gzipped)
Total:                    ~58 KB
```

---

## Testing

### Casos de Prueba Recomendados

1. **Selector de Secciones**
   - ✓ Cambiar sección actualiza timeline
   - ✓ Cambiar sección actualiza pines visibles
   - ✓ Secciones se ordenan correctamente

2. **Modo Lluvia**
   - ✓ Toggle activa/desactiva modo
   - ✓ Pines se mueven a nuevas coordenadas
   - ✓ Interfaz cambia de color
   - ✓ Banner de alerta se muestra en modo lluvia

3. **Responsividad**
   - ✓ Panel se abre/cierra en móvil
   - ✓ Grid de secciones se ajusta a pantalla
   - ✓ SVG del mapa se escala correctamente

4. **Asignación de Aulas**
   - ✓ Búsqueda filtra secciones
   - ✓ Click en sección muestra detalles
   - ✓ Tabla muestra todas las asignaciones

---

## Troubleshooting

### Los pines no se mueven en modo lluvia
**Solución**: Verificar que `rainX` y `rainY` están definidos en `PIN_LOCATIONS`

### El timeline no se actualiza al cambiar sección
**Solución**: Verificar que `currentSchedule` se pasa correctamente desde App.tsx

### La interfaz se ve cortada en móvil
**Solución**: Verificar que viewport meta tag está en `index.html`

### Animación demasiado rápida/lenta
**Solución**: Ajustar `duration-*` en Tailwind classes o modificar tiempos en `index.css`

---

## Dependencias Principales

```json
{
  "react": "^18.2.0",
  "react-dom": "^18.2.0",
  "lucide-react": "^0.263.0",  // Icons
  "typescript": "^5.0.0",
  "tailwindcss": "^3.3.0",
  "vite": "^5.0.0"
}
```

---

## Notas de Desarrollo

- **No usar localStorage/sessionStorage** por ahora (datos son locales)
- **Evitar cambios en estructura SVG** sin actualizar coordenadas de pines
- **Siempre mantener 15 actividades por sección** en schedules.ts
- **Los IDs de pines deben ser únicos** para evitar conflictos de render
- **Las transiciones de color deben ser suaves** (mínimo 300ms)

---

## Versión
**v1.0.0** - Mayo 2026

Para más información, ver `APLICACION_README.md`
