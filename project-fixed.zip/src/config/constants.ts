// Configuración global y constantes de la aplicación

export const APP_CONFIG = {
  name: 'Cotepecos - Día de Votaciones 2026',
  school: 'Colegio Técnico 1978',
  eventDate: '29 de mayo de 2026',
  startTime: '12:10 p.m.',
  endTime: '3:50 p.m.',
};

export const TIME_WINDOWS = {
  MORNING_START: '9:20 a.m.',
  MORNING_END: '11:20 a.m.',
  AFTERNOON_START: '12:10 p.m.',
  AFTERNOON_END: '3:50 p.m.',
  BELONGINGS_COLLECTION: '3:50 p.m.',
};

export const SCHEDULE_CONFIG = {
  TOTAL_SECTIONS: 19,
  TOTAL_ACTIVITIES_PER_SECTION: 15,
  STATION_DURATION_MINUTES: 15,
  ACTIVITY_AREAS: [
    'Aula 25', 'Aula 26', 'Aula 32', 'Aula 33', 'Aula 34', 'Aula 35', 'Aula 36', 'Aula 37',
    'Zona 1', 'Zona 3', 'Zona 4', 'Aula Ecológica', 'Entrada Principal',
    'Multiusos'
  ]
};

export const RAIN_MODE_CONFIG = {
  ENABLED: true,
  RELOCATABLE_ZONES: ['Zona 1', 'Zona 3', 'Zona 4', 'Aula Ecológica', 'Entrada Principal'],
  VISUAL_SETTINGS: {
    RAIN_OVERLAY_OPACITY: 0.1,
    PIN_PULSE_DURATION: '2s',
    TRANSITION_DURATION: '500ms',
  }
};

export const SECTIONS = [
  // Décimo
  '10-1', '10-2', '10-3', '10-4', '10-5', '10-6',
  // Undécimo
  '11-1', '11-2', '11-3', '11-4', '11-5', '11-6', '11-7',
  // Duodécimo
  '12-1', '12-2', '12-3', '12-4', '12-5', '12-6'
];

export const BELONGINGS_CLASSROOM_MAPPING = {
  '10-1': '22', '10-2': '3',  '10-3': '19', '10-4': '15', '10-5': '1',  '10-6': '1',
  '11-1': '2',  '11-2': '11', '11-3': '13', '11-4': '8',  '11-5': '24', '11-6': '24',
  '11-7': '23',
  '12-1': '5',  '12-2': '4',  '12-3': '21', '12-4': '12', '12-5': '12', '12-6': '10'
} as Record<string, string>;

export const CLASSROOM_DESCRIPTIONS = {
  '1': 'Aula del primer piso',
  '2': 'Aula del segundo bloque',
  '3': 'Aula de especialidad',
  '4': 'Aula de informática',
  '5': 'Aula de general',
  // ... más descripciones según sea necesario
};

export const COLORS = {
  PRIMARY: '#2563eb',      // blue-600
  PRIMARY_DARK: '#1e40af', // blue-800
  SECONDARY: '#1f2937',    // gray-800
  SUCCESS: '#10b981',      // emerald-500
  WARNING: '#f97316',      // orange-500
  DANGER: '#ef4444',       // red-500
  INFO: '#0ea5e9',         // cyan-500
  SLATE_900: '#0f172a',
  SLATE_800: '#1e293b',
  SLATE_700: '#334155',
  SLATE_600: '#475569',
} as const;

export const ICON_SETS = {
  CLASSROOM: '📚',
  ZONE_1: '🎮',
  ZONE_3: '🏀',
  ZONE_4: '⚽',
  ECOLOGICAL: '🌱',
  ENTRANCE: '🚪',
  CAFETERIA: '🍽️',
  GYM: '🏋️',
  DANCE: '💃',
  ALERT: '⚠️',
  INFO: 'ℹ️',
  RAIN: '🌧️',
  CLOUD: '☁️',
} as const;

export const PROFESSOR_ASSIGNMENTS = {
  'Aula 32': 'Manuel Jiménez',
  'Aula 33': 'Johan Reyes',
  'Aula 34': 'Patricia Araya',
  'Aula 35': 'Anthony Lestrange',
  'Aula 36': 'Seidi Portilla',
  'Aula 37': 'Sofía Rodríguez',
  'Aula 25': 'Marilén Cárdenas',
  'Aula 26': 'Marvin Sánchez',
  'Aula Ecológica': 'Gabriela Vásquez',
  'Entrada Principal': 'Elthon Agüero, Diego Chinchilla',
  'Zona 1': 'Neidy Mairena',
  'Zona 3': 'Kattia Castro, Ivannia Jara, Eduany Navarrete, Jenniffer Sequeira',
  'Zona 4': 'Juan Carlos Argüello, Roberto Chacón',
  'Multiusos': 'Sairis Benavides, Damaris Prado',
} as Record<string, string>;
