import { useState } from 'react';
import { Menu, X } from 'lucide-react';
import MapView from './components/MapView';
import BelongingsView from './components/BelongingsView';
import { SCHEDULES } from './data/schedules';

type ViewType = 'map' | 'belongings';

function App() {
  const [activeView, setActiveView] = useState<ViewType>('map');
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [selectedSection, setSelectedSection] = useState('10-1');
  const [isRainMode, setIsRainMode] = useState(false);

  const sections = Object.keys(SCHEDULES).sort();
  const currentSchedule = SCHEDULES[selectedSection]?.schedule || [];

  const handleSectionChange = (section: string) => {
    setSelectedSection(section);
  };

  const handleRainModeToggle = () => {
    setIsRainMode(!isRainMode);
  };

  return (
    <div className={`min-h-screen transition-all duration-500 ${
      isRainMode
        ? 'bg-gradient-to-br from-slate-700 via-slate-600 to-slate-800'
        : 'bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900'
    }`}>
      {/* Header Navigation */}
      <header className="bg-slate-950 border-b border-slate-700 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <img src="/Escudo_2026.png" alt="Logo" className="w-10 h-10" />
            <div>
              <h1 className="text-white font-bold text-lg">Cotepecos</h1>
              <p className="text-xs text-slate-400">Día de Votaciones</p>
            </div>
          </div>

          <nav className="hidden md:flex gap-2">
            <button
              onClick={() => setActiveView('map')}
              className={`px-4 py-2 rounded-lg font-medium transition-all ${
                activeView === 'map'
                  ? 'bg-blue-600 text-white'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              Mapa Interactivo
            </button>
            <button
              onClick={() => setActiveView('belongings')}
              className={`px-4 py-2 rounded-lg font-medium transition-all ${
                activeView === 'belongings'
                  ? 'bg-blue-600 text-white'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              Asignación de Aulas
            </button>
          </nav>

          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="md:hidden p-2 bg-slate-800 rounded-lg text-white hover:bg-slate-700"
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden border-t border-slate-700 bg-slate-900 px-4 py-3 space-y-2">
            <button
              onClick={() => {
                setActiveView('map');
                setIsMenuOpen(false);
              }}
              className={`w-full px-4 py-2 rounded-lg font-medium transition-all text-left ${
                activeView === 'map'
                  ? 'bg-blue-600 text-white'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              Mapa Interactivo
            </button>
            <button
              onClick={() => {
                setActiveView('belongings');
                setIsMenuOpen(false);
              }}
              className={`w-full px-4 py-2 rounded-lg font-medium transition-all text-left ${
                activeView === 'belongings'
                  ? 'bg-blue-600 text-white'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              Asignación de Aulas
            </button>
          </div>
        )}
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 py-6">
        {activeView === 'map' ? (
          <MapView
            selectedSection={selectedSection}
            isRainMode={isRainMode}
            onSectionChange={handleSectionChange}
            onRainModeToggle={handleRainModeToggle}
            sections={sections}
            currentSchedule={currentSchedule}
          />
        ) : (
          <BelongingsView />
        )}
      </main>
    </div>
  );
}

export default App;
