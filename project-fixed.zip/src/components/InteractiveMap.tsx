import { useState } from 'react';
import { AlertTriangle, X } from 'lucide-react';
import { SCHEDULES } from '../data/schedules';

interface PinConfig {
  id: string;
  label: string;
  icon: string;
  // Coordinates in SVG viewBox space (1200 x 900)
  normalX: number;
  normalY: number;
  rainX?: number;
  rainY?: number;
  color: string;
  isRelocatable: boolean;
  details?: {
    originalLocation: string;
    rainLocation: string;
    responsible: string;
    activities: string;
  };
}

interface InteractiveMapProps {
  isRainMode: boolean;
  selectedSection: string;
}

// SVG viewBox: 1200 x 900
// Layout matches CROQUIS.jpg exactly

const PINS: PinConfig[] = [
  // Aulas fijas - fila superior (31-37)
  { id: 'aula31', label: 'Aula 31', icon: '📚', normalX: 175, normalY: 390, color: '#3b82f6', isRelocatable: false },
  { id: 'aula32', label: 'Aula 32', icon: '📚', normalX: 270, normalY: 390, color: '#3b82f6', isRelocatable: false },
  { id: 'aula33', label: 'Aula 33', icon: '📚', normalX: 365, normalY: 390, color: '#3b82f6', isRelocatable: false },
  { id: 'aula34', label: 'Aula 34', icon: '📚', normalX: 460, normalY: 390, color: '#3b82f6', isRelocatable: false },
  { id: 'aula35', label: 'Aula 35', icon: '📚', normalX: 555, normalY: 390, color: '#3b82f6', isRelocatable: false },
  { id: 'aula36', label: 'Aula 36', icon: '📚', normalX: 650, normalY: 390, color: '#3b82f6', isRelocatable: false },
  { id: 'aula37', label: 'Aula 37', icon: '📚', normalX: 745, normalY: 390, color: '#3b82f6', isRelocatable: false },

  // Aulas fijas - fila inferior (25-28) + Biblioteca
  { id: 'aula28', label: 'Aula 28', icon: '📚', normalX: 270, normalY: 790, color: '#3b82f6', isRelocatable: false },
  { id: 'aula27', label: 'Aula 27', icon: '📚', normalX: 365, normalY: 790, color: '#3b82f6', isRelocatable: false },
  { id: 'aula26', label: 'Aula 26', icon: '📚', normalX: 460, normalY: 790, color: '#3b82f6', isRelocatable: false },
  { id: 'aula25', label: 'Aula 25', icon: '📚', normalX: 555, normalY: 790, color: '#3b82f6', isRelocatable: false },
  { id: 'biblioteca', label: 'Biblioteca', icon: '📖', normalX: 670, normalY: 790, color: '#3b82f6', isRelocatable: false },

  // Multiusos (fijo)
  { id: 'multiusos', label: 'Multiusos', icon: '💃', normalX: 145, normalY: 590, color: '#ec4899', isRelocatable: false },

  // Zona 1 - patio central grande
  {
    id: 'zona1', label: 'Zona 1', icon: '🎮',
    normalX: 470, normalY: 600,
    rainX: 600, rainY: 320,
    color: '#8b5cf6', isRelocatable: true,
    details: {
      originalLocation: 'Patio Central (Zona 1)',
      rainLocation: 'Pasillo enfrente del Comedor',
      responsible: 'Neidy Mairena',
      activities: 'Piedra, Papel y Salta / Captura la cola / Conteo Alternativo',
    },
  },

  // Zona 3 - patio exterior superior centro
  {
    id: 'zona3', label: 'Zona 3', icon: '🏀',
    normalX: 560, normalY: 150,
    rainX: 920, rainY: 760,
    color: '#a855f7', isRelocatable: true,
    details: {
      originalLocation: 'Patio Norte (Zona 3)',
      rainLocation: 'Rampa techada de la Entrada Principal',
      responsible: 'Kattia Castro, Ivannia Jara, Eduany Navarrete, Jenniffer Sequeira',
      activities: 'Marco Polo / Suelta la barra',
    },
  },

  // Zona 4 - exterior izquierdo (Soda area)
  {
    id: 'zona4', label: 'Zona 4', icon: '⚽',
    normalX: 130, normalY: 150,
    rainX: 460, rainY: 450,
    color: '#06b6d4', isRelocatable: true,
    details: {
      originalLocation: 'Patio Exterior (Zona 4 / Soda)',
      rainLocation: 'Pasillo Principal Techado de Aulas',
      responsible: 'Juan Carlos Argüello, Roberto Chacón',
      activities: 'Pulpo / Captura la bandera',
    },
  },

  // Aula Ecológica
  {
    id: 'aulaEco', label: 'Aula Ecológica', icon: '🌱',
    normalX: 1000, normalY: 490,
    rainX: 615, normalY: 790,
    rainX: 615, rainY: 790,
    color: '#10b981', isRelocatable: true,
    details: {
      originalLocation: 'Aula Ecológica (exterior derecho)',
      rainLocation: 'Pasillo techado frente a la Biblioteca',
      responsible: 'Gabriela Vásquez',
      activities: 'Estatuas Musicales',
    },
  },

  // Entrada Principal
  {
    id: 'entrada', label: 'Entrada Principal', icon: '🚪',
    normalX: 900, normalY: 680,
    rainX: 900, rainY: 590,
    color: '#f97316', isRelocatable: true,
    details: {
      originalLocation: 'Entrada Principal exterior',
      rainLocation: 'Pasillo de Administración interior',
      responsible: 'Elthon Agüero y Diego Chinchilla',
      activities: 'Baúl',
    },
  },
];

export default function InteractiveMap({ isRainMode, selectedSection }: InteractiveMapProps) {
  const [selectedPinId, setSelectedPinId] = useState<string | null>(null);

  const handlePinClick = (pinId: string) => {
    setSelectedPinId(selectedPinId === pinId ? null : pinId);
  };

  const selectedPin = PINS.find(p => p.id === selectedPinId);

  const getActivitiesForPin = (pinId: string) => {
    const schedule = SCHEDULES[selectedSection]?.schedule || [];
    const pin = PINS.find(p => p.id === pinId);
    if (!pin) return [];
    return schedule.filter(activity => {
      const place = activity.place.toLowerCase();
      const pinLabel = pin.label.toLowerCase();
      return place.includes(pinLabel.replace('aula ', '').replace('zona ', ''));
    });
  };

  return (
    <div className="relative w-full rounded-2xl overflow-hidden border border-slate-600 shadow-xl bg-slate-900">
      {/* SVG Map */}
      <svg
        viewBox="0 0 1200 900"
        xmlns="http://www.w3.org/2000/svg"
        className="w-full h-full"
        style={{ display: 'block' }}
      >
        {/* ── BACKGROUND ── */}
        <rect width="1200" height="900" fill={isRainMode ? '#0f172a' : '#f8fafc'} />

        {/* ── EXTERIOR BUILDINGS (outside main campus) ── */}

        {/* SODA - top left */}
        <rect x="60" y="60" width="200" height="180" rx="4" fill={isRainMode ? '#1e293b' : '#e2e8f0'} stroke={isRainMode ? '#475569' : '#94a3b8'} strokeWidth="2" />
        <text x="160" y="158" textAnchor="middle" fontSize="16" fontWeight="bold" fill={isRainMode ? '#94a3b8' : '#475569'} fontFamily="monospace">SODA</text>

        {/* ZONA 3 building - top center */}
        <rect x="420" y="45" width="220" height="200" rx="4" fill={isRainMode ? '#1e293b' : '#e2e8f0'} stroke={isRainMode ? '#475569' : '#94a3b8'} strokeWidth="2" />
        <text x="530" y="152" textAnchor="middle" fontSize="16" fontWeight="bold" fill={isRainMode ? '#94a3b8' : '#475569'} fontFamily="monospace">ZONA 3</text>

        {/* COMEDOR - top center-right */}
        <rect x="670" y="120" width="200" height="120" rx="4" fill={isRainMode ? '#1e293b' : '#e2e8f0'} stroke={isRainMode ? '#475569' : '#94a3b8'} strokeWidth="2" />
        <text x="770" y="187" textAnchor="middle" fontSize="14" fontWeight="bold" fill={isRainMode ? '#94a3b8' : '#475569'} fontFamily="monospace">COMEDOR</text>
        {/* small square below comedor */}
        <rect x="750" y="238" width="40" height="30" rx="2" fill={isRainMode ? '#1e293b' : '#e2e8f0'} stroke={isRainMode ? '#475569' : '#94a3b8'} strokeWidth="1.5" />

        {/* GIMNASIO - top right */}
        <rect x="930" y="60" width="210" height="180" rx="4" fill={isRainMode ? '#1e293b' : '#e2e8f0'} stroke={isRainMode ? '#475569' : '#94a3b8'} strokeWidth="2" />
        <text x="1035" y="158" textAnchor="middle" fontSize="16" fontWeight="bold" fill={isRainMode ? '#94a3b8' : '#475569'} fontFamily="monospace">GIMNASIO</text>

        {/* ── MAIN CAMPUS RECTANGLE ── */}
        <rect x="80" y="300" width="860" height="550" rx="4" fill="none" stroke={isRainMode ? '#64748b' : '#475569'} strokeWidth="3" />

        {/* ── AULAS ROW TOP (31-37) ── */}
        {[
          { n: '31', x: 130 }, { n: '32', x: 225 }, { n: '33', x: 320 },
          { n: '34', x: 415 }, { n: '35', x: 510 }, { n: '36', x: 605 }, { n: '37', x: 700 }
        ].map(({ n, x }) => (
          <g key={n}>
            <rect x={x} y={330} width="80" height="100" rx="3"
              fill={isRainMode ? '#1e293b' : '#dbeafe'}
              stroke={isRainMode ? '#3b82f6' : '#93c5fd'} strokeWidth="1.5" />
            <text x={x + 40} y={387} textAnchor="middle" fontSize="14" fontWeight="bold"
              fill={isRainMode ? '#60a5fa' : '#1d4ed8'} fontFamily="monospace">{n}</text>
          </g>
        ))}

        {/* Stairs / escaleras - top right of aulas */}
        {[0, 1, 2, 3, 4].map(i => (
          <rect key={i} x={800} y={330 + i * 20} width="50" height="18" rx="1"
            fill={isRainMode ? '#334155' : '#cbd5e1'}
            stroke={isRainMode ? '#475569' : '#94a3b8'} strokeWidth="1" />
        ))}

        {/* ── MULTIUSOS - left side ── */}
        <rect x="90" y="440" width="160" height="280" rx="4"
          fill={isRainMode ? '#2d1b4e' : '#fdf4ff'}
          stroke={isRainMode ? '#a855f7' : '#c084fc'} strokeWidth="2" />
        <text x="170" y="568" textAnchor="middle" fontSize="13" fontWeight="bold"
          fill={isRainMode ? '#c084fc' : '#7e22ce'} fontFamily="monospace"
          style={{ writingMode: 'vertical-rl', transform: 'rotate(180deg)', transformOrigin: '170px 568px' }}>
        </text>
        {/* MULTIUSOS vertical text using tspan rotation trick */}
        <text transform="translate(170,580) rotate(-90)" textAnchor="middle" fontSize="13" fontWeight="bold"
          fill={isRainMode ? '#c084fc' : '#7e22ce'} fontFamily="monospace">MULTIUSOS</text>

        {/* ── ZONA 1 - central patio ── */}
        <rect x="270" y="450" width="400" height="270" rx="4"
          fill={isRainMode ? '#1a1040' : '#ede9fe'}
          stroke={isRainMode ? '#8b5cf6' : '#a78bfa'} strokeWidth="2" />
        <text x="470" y="592" textAnchor="middle" fontSize="18" fontWeight="bold"
          fill={isRainMode ? '#a78bfa' : '#5b21b6'} fontFamily="monospace">ZONA 1</text>

        {/* ── AULA ECOLOGICA - right side ── */}
        <rect x="920" y="400" width="160" height="160" rx="4"
          fill={isRainMode ? '#052e16' : '#dcfce7'}
          stroke={isRainMode ? '#10b981' : '#4ade80'} strokeWidth="2" />
        <text x="1000" y="472" textAnchor="middle" fontSize="12" fontWeight="bold"
          fill={isRainMode ? '#34d399' : '#15803d'} fontFamily="monospace">AULA</text>
        <text x="1000" y="490" textAnchor="middle" fontSize="12" fontWeight="bold"
          fill={isRainMode ? '#34d399' : '#15803d'} fontFamily="monospace">ECOLOGICA</text>

        {/* ── ZONA 2 label - right exterior ── */}
        <text x="1080" y="640" textAnchor="middle" fontSize="14" fontWeight="bold"
          fill={isRainMode ? '#94a3b8' : '#64748b'} fontFamily="monospace">ZONA 2</text>
        {/* Octagon shape for zona 2 */}
        <polygon points="1050,660 1070,650 1100,650 1120,660 1120,690 1100,700 1070,700 1050,690"
          fill={isRainMode ? '#1e293b' : '#e2e8f0'}
          stroke={isRainMode ? '#475569' : '#94a3b8'} strokeWidth="1.5" />

        {/* ── ENTRADA PRINCIPAL - right side ── */}
        <text transform="translate(908,720) rotate(-90)" textAnchor="middle" fontSize="11" fontWeight="bold"
          fill={isRainMode ? '#fb923c' : '#9a3412'} fontFamily="monospace">ENTRADA PRINCIPAL</text>

        {/* Stairs bottom right */}
        {[0, 1, 2, 3, 4].map(i => (
          <rect key={i} x={880 + i * 12} y={800} width="10" height="50" rx="1"
            fill={isRainMode ? '#334155' : '#cbd5e1'}
            stroke={isRainMode ? '#475569' : '#94a3b8'} strokeWidth="1" />
        ))}

        {/* ── AULAS ROW BOTTOM (28, 27, 26, 25) + BIBLIOTECA ── */}
        {[
          { n: '28', x: 225 }, { n: '27', x: 320 }, { n: '26', x: 415 }, { n: '25', x: 510 }
        ].map(({ n, x }) => (
          <g key={n}>
            <rect x={x} y={740} width="80" height="100" rx="3"
              fill={isRainMode ? '#1e293b' : '#dbeafe'}
              stroke={isRainMode ? '#3b82f6' : '#93c5fd'} strokeWidth="1.5" />
            <text x={x + 40} y={797} textAnchor="middle" fontSize="14" fontWeight="bold"
              fill={isRainMode ? '#60a5fa' : '#1d4ed8'} fontFamily="monospace">{n}</text>
          </g>
        ))}

        {/* BIBLIOTECA */}
        <rect x="610" y="740" width="120" height="100" rx="3"
          fill={isRainMode ? '#1e293b' : '#dbeafe'}
          stroke={isRainMode ? '#3b82f6' : '#93c5fd'} strokeWidth="1.5" />
        <text x="670" y="793" textAnchor="middle" fontSize="11" fontWeight="bold"
          fill={isRainMode ? '#60a5fa' : '#1d4ed8'} fontFamily="monospace">BIBLIO-</text>
        <text x="670" y="808" textAnchor="middle" fontSize="11" fontWeight="bold"
          fill={isRainMode ? '#60a5fa' : '#1d4ed8'} fontFamily="monospace">TECA</text>

        {/* ── BOTTOM BAR ── */}
        <rect x="80" y="858" width="860" height="30" rx="2"
          fill={isRainMode ? '#1e293b' : '#e2e8f0'}
          stroke={isRainMode ? '#475569' : '#94a3b8'} strokeWidth="1.5" />

        {/* ── PINS ── */}
        {PINS.map(pin => {
          const isRelocated = isRainMode && pin.isRelocatable;
          const cx = isRelocated && pin.rainX != null ? pin.rainX : pin.normalX;
          const cy = isRelocated && pin.rainY != null ? pin.rainY : pin.normalY;
          const isSelected = selectedPinId === pin.id;
          const displayColor = isRelocated ? '#f97316' : pin.color;
          const r = isSelected ? 28 : 22;

          return (
            <g
              key={pin.id}
              style={{ cursor: 'pointer', transition: 'all 0.5s ease' }}
              onClick={() => handlePinClick(pin.id)}
            >
              {/* Glow ring when selected */}
              {isSelected && (
                <circle cx={cx} cy={cy} r={r + 6} fill="none" stroke="white" strokeWidth="3" opacity="0.6" />
              )}
              {/* Pulse ring in rain mode */}
              {isRelocated && (
                <circle cx={cx} cy={cy} r={r + 10} fill={displayColor} opacity="0.25">
                  <animate attributeName="r" from={r + 4} to={r + 16} dur="1.5s" repeatCount="indefinite" />
                  <animate attributeName="opacity" from="0.3" to="0" dur="1.5s" repeatCount="indefinite" />
                </circle>
              )}
              {/* Main circle */}
              <circle cx={cx} cy={cy} r={r} fill={displayColor} opacity="0.95" />
              {/* Icon */}
              <text x={cx} y={cy + 6} textAnchor="middle" fontSize={isSelected ? '18' : '14'}>
                {pin.icon}
              </text>
              {/* Label */}
              <text x={cx} y={cy + r + 14} textAnchor="middle" fontSize="10" fontWeight="bold"
                fill={isRainMode ? '#f1f5f9' : '#1e293b'} fontFamily="monospace"
                style={{ textShadow: isRainMode ? '1px 1px 2px #000' : '1px 1px 2px #fff' }}>
                {pin.label}
              </text>
              {/* Warning badge */}
              {isRelocated && (
                <g>
                  <circle cx={cx + r - 2} cy={cy - r + 2} r="9" fill="#f59e0b" />
                  <text x={cx + r - 2} y={cy - r + 6} textAnchor="middle" fontSize="9">⚠️</text>
                </g>
              )}
            </g>
          );
        })}
      </svg>

      {/* ── PIN DETAILS MODAL ── */}
      {selectedPin && (
        <div
          className={`absolute bottom-4 left-4 right-4 rounded-xl shadow-2xl p-5 max-h-56 overflow-y-auto z-20 transition-all ${
            isRainMode
              ? 'bg-slate-800 border-2 border-orange-500'
              : 'bg-white border border-slate-200'
          }`}
        >
          <div className="flex items-start justify-between mb-3">
            <div className="flex items-center gap-2">
              <span className="text-3xl">{selectedPin.icon}</span>
              <h3 className={`font-bold text-lg ${isRainMode ? 'text-slate-100' : 'text-slate-900'}`}>
                {selectedPin.label}
              </h3>
            </div>
            <button
              onClick={() => setSelectedPinId(null)}
              className={`p-1 rounded transition-colors ${
                isRainMode ? 'text-slate-400 hover:bg-slate-700' : 'text-slate-400 hover:bg-slate-100'
              }`}
            >
              <X size={20} />
            </button>
          </div>

          {isRainMode && selectedPin.isRelocatable && selectedPin.details && (
            <div className="bg-gradient-to-r from-orange-900 to-orange-800 border-l-4 border-orange-400 p-3 rounded mb-3">
              <div className="flex items-start gap-2">
                <AlertTriangle size={18} className="text-orange-300 flex-shrink-0 mt-0.5" />
                <div className="text-sm text-orange-100">
                  <p className="font-bold mb-2">REUBICADO POR LLUVIA</p>
                  <p className="text-xs mb-1"><strong>Original:</strong> {selectedPin.details.originalLocation}</p>
                  <p className="text-xs mb-1"><strong>Lluvia:</strong> {selectedPin.details.rainLocation}</p>
                  <p className="text-xs"><strong>Responsable:</strong> {selectedPin.details.responsible}</p>
                </div>
              </div>
            </div>
          )}

          {selectedPin.details && (
            <div className={`text-sm ${isRainMode ? 'text-slate-300' : 'text-slate-700'}`}>
              <p className={`font-semibold mb-2 ${isRainMode ? 'text-slate-100' : 'text-slate-900'}`}>
                Actividades de {selectedSection}:
              </p>
              <div className="space-y-1">
                {getActivitiesForPin(selectedPin.id).length > 0 ? (
                  getActivitiesForPin(selectedPin.id).map((activity, idx) => (
                    <p key={idx} className="text-xs">
                      <strong>{activity.activity}</strong> ({activity.time})
                    </p>
                  ))
                ) : (
                  <p className="text-xs italic opacity-60">
                    No hay actividades asignadas a esta ubicación para {selectedSection}
                  </p>
                )}
              </div>
              <p className="text-xs mt-2 font-medium">
                Responsable: {selectedPin.details.responsible}
              </p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
