import { useState } from 'react';
import { Cloud, ChevronDown, ChevronUp, AlertTriangle } from 'lucide-react';
import InteractiveMap from './InteractiveMap';
import ScheduleTimeline from './ScheduleTimeline';
import { Activity } from '../data/schedules';

interface MapViewProps {
  selectedSection: string;
  isRainMode: boolean;
  onSectionChange: (section: string) => void;
  onRainModeToggle: () => void;
  sections: string[];
  currentSchedule: Activity[];
}

export default function MapView({
  selectedSection,
  isRainMode,
  onSectionChange,
  onRainModeToggle,
  sections,
  currentSchedule,
}: MapViewProps) {
  const [isPanelOpen, setIsPanelOpen] = useState(false);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 h-screen lg:h-auto">
      {/* Sidebar Panel - Collapsible on mobile */}
      <div
        className={`lg:col-span-1 transition-all duration-300 ${
          isPanelOpen ? 'fixed inset-0 z-50 lg:static lg:z-auto' : 'hidden lg:block'
        }`}
      >
        <div
          className={`h-full lg:h-auto rounded-xl p-6 overflow-y-auto ${
            isRainMode ? 'bg-slate-700 border-2 border-orange-500' : 'bg-slate-800 border border-slate-700'
          }`}
        >
          <div className="flex items-center justify-between lg:hidden mb-4">
            <h2 className="text-white font-bold">Filtros y Horarios</h2>
            <button
              onClick={() => setIsPanelOpen(false)}
              className="text-slate-300 hover:text-white"
            >
              ✕
            </button>
          </div>

          {/* Section Selector */}
          <div className="mb-6">
            <label className="block text-slate-300 text-sm font-semibold mb-3">
              Selecciona tu sección
            </label>
            <div className="grid grid-cols-2 gap-2">
              {sections.map(section => (
                <button
                  key={section}
                  onClick={() => {
                    onSectionChange(section);
                    setIsPanelOpen(false);
                  }}
                  className={`py-2 px-3 rounded-lg font-bold transition-all text-sm ${
                    selectedSection === section
                      ? isRainMode
                        ? 'bg-orange-500 text-white shadow-lg'
                        : 'bg-blue-600 text-white shadow-lg'
                      : isRainMode
                      ? 'bg-slate-600 text-slate-200 hover:bg-slate-500'
                      : 'bg-slate-700 text-slate-300 hover:bg-slate-600'
                  }`}
                >
                  {section}
                </button>
              ))}
            </div>
          </div>

          {/* Rain Mode Button */}
          <div className="mb-6">
            <button
              onClick={() => {
                onRainModeToggle();
                setIsPanelOpen(false);
              }}
              className={`w-full flex items-center justify-center gap-2 py-3 px-4 rounded-lg font-bold transition-all ${
                isRainMode
                  ? 'bg-orange-500 text-white shadow-lg scale-105'
                  : 'bg-blue-600 text-white hover:bg-blue-700'
              }`}
            >
              <Cloud size={20} />
              {isRainMode ? 'Modo Lluvia Activado' : 'Activar Modo Lluvia'}
            </button>
          </div>

          {/* Timeline */}
          <div className="border-t border-slate-600 pt-6">
            <h3 className="text-white font-bold text-sm mb-4 flex items-center gap-2">
              📅 Cronograma de {selectedSection}
            </h3>
            <ScheduleTimeline schedule={currentSchedule} isRainMode={isRainMode} />
          </div>
        </div>
      </div>

      {/* Map Container */}
      <div className="lg:col-span-3 relative">
        <InteractiveMap isRainMode={isRainMode} selectedSection={selectedSection} />

        {/* Mobile Panel Toggle Button */}
        <button
          onClick={() => setIsPanelOpen(!isPanelOpen)}
          className={`lg:hidden fixed bottom-6 right-6 z-40 p-4 rounded-full shadow-lg transition-all ${
            isRainMode
              ? 'bg-orange-500 text-white hover:bg-orange-600'
              : 'bg-blue-600 text-white hover:bg-blue-700'
          }`}
        >
          {isPanelOpen ? <ChevronDown size={24} /> : <ChevronUp size={24} />}
        </button>
      </div>
    </div>
  );
}
