import { Activity } from '../data/schedules';
import { MapPin, Clock } from 'lucide-react';

interface ScheduleTimelineProps {
  schedule: Activity[];
  isRainMode: boolean;
}

export default function ScheduleTimeline({ schedule, isRainMode }: ScheduleTimelineProps) {
  return (
    <div className="space-y-3 max-h-96 overflow-y-auto pr-2">
      {schedule.map((activity, index) => {
        const isRainyLocation =
          isRainMode &&
          (activity.place === 'Zona 1' ||
            activity.place === 'Zona 3' ||
            activity.place === 'Zona 4' ||
            activity.place === 'Aula Ecológica' ||
            activity.place === 'Entrada Principal');

        return (
          <div
            key={index}
            className={`p-3 rounded-lg text-sm transition-all ${
              isRainyLocation
                ? 'bg-gradient-to-r from-orange-900 to-orange-800 border border-orange-600'
                : isRainMode
                ? 'bg-slate-600'
                : 'bg-slate-700'
            }`}
          >
            <div className="flex items-start gap-2">
              <span
                className={`inline-block w-6 h-6 rounded-full text-xs font-bold text-center flex items-center justify-center flex-shrink-0 ${
                  isRainyLocation
                    ? 'bg-orange-400 text-orange-900'
                    : isRainMode
                    ? 'bg-slate-500 text-slate-100'
                    : 'bg-blue-500 text-white'
                }`}
              >
                {activity.station}
              </span>
              <div className="flex-1">
                <h4 className={`font-semibold text-sm ${
                  isRainMode ? 'text-slate-100' : 'text-white'
                }`}>
                  {activity.activity}
                </h4>
                <div className="flex items-center gap-1 text-xs mt-1">
                  <MapPin size={12} className={isRainMode ? 'text-slate-300' : 'text-slate-300'} />
                  <span className={isRainMode ? 'text-slate-300' : 'text-slate-300'}>
                    {activity.place}
                  </span>
                </div>
                <div className="flex items-center gap-1 text-xs mt-1">
                  <Clock size={12} className={isRainMode ? 'text-slate-300' : 'text-slate-300'} />
                  <span className={isRainMode ? 'text-slate-300' : 'text-slate-300'}>
                    {activity.time}
                  </span>
                </div>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}
