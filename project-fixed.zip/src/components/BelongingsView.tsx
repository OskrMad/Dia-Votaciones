import { useState } from 'react';
import { Search } from 'lucide-react';

const BELONGINGS_ASSIGNMENT: Record<string, string> = {
  '10-1': '22',
  '10-2': '3',
  '10-3': '19',
  '10-4': '15',
  '10-5': '1',
  '10-6': '1',
  '11-1': '2',
  '11-2': '11',
  '11-3': '13',
  '11-4': '8',
  '11-5': '24',
  '11-6': '24',
  '11-7': '23',
  '12-1': '5',
  '12-2': '4',
  '12-3': '21',
  '12-4': '12',
  '12-5': '12',
  '12-6': '10',
};

export default function BelongingsView() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedSection, setSelectedSection] = useState<string | null>(null);

  const sections = Object.keys(BELONGINGS_ASSIGNMENT).sort();
  const filteredSections = sections.filter(section =>
    section.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-gradient-to-r from-blue-600 to-blue-700 rounded-xl p-8 mb-8 text-white">
        <h2 className="text-3xl font-bold mb-2">Asignación de Aulas para Pertenencias</h2>
        <p className="text-blue-100">
          Encuentra dónde dejar tus bultos antes de las 12:10 p.m.
        </p>
      </div>

      {/* Search Bar */}
      <div className="mb-8">
        <div className="relative">
          <Search className="absolute left-3 top-3 text-slate-400" size={20} />
          <input
            type="text"
            placeholder="Busca tu sección (ej: 10-1, 11-3, 12-5)..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-3 rounded-lg bg-slate-700 border border-slate-600 text-white placeholder-slate-400 focus:outline-none focus:border-blue-500"
          />
        </div>
      </div>

      {/* Results Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 mb-8">
        {filteredSections.map(section => (
          <button
            key={section}
            onClick={() => setSelectedSection(selectedSection === section ? null : section)}
            className={`p-6 rounded-xl transition-all transform hover:scale-105 ${
              selectedSection === section
                ? 'bg-gradient-to-br from-blue-600 to-blue-700 text-white shadow-lg scale-105'
                : 'bg-slate-800 text-slate-100 hover:bg-slate-700 border border-slate-700'
            }`}
          >
            <div className="flex items-center justify-between">
              <div>
                <p className="text-2xl font-bold">{section}</p>
                <p className={`text-sm mt-2 ${
                  selectedSection === section ? 'text-blue-100' : 'text-slate-400'
                }`}>
                  Aula {BELONGINGS_ASSIGNMENT[section]}
                </p>
              </div>
              <div className={`text-4xl font-bold ${
                selectedSection === section ? 'text-blue-100' : 'text-blue-500'
              }`}>
                {BELONGINGS_ASSIGNMENT[section]}
              </div>
            </div>
          </button>
        ))}
      </div>

      {/* Detailed View */}
      {selectedSection && (
        <div className="bg-gradient-to-br from-slate-800 to-slate-900 rounded-xl p-8 border border-slate-700">
          <div className="mb-6">
            <h3 className="text-3xl font-bold text-white mb-2">Sección {selectedSection}</h3>
            <div className="h-1 w-20 bg-gradient-to-r from-blue-500 to-blue-600 rounded"></div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="space-y-4">
              <div>
                <p className="text-slate-400 text-sm mb-2">TU SECCIÓN</p>
                <p className="text-white text-4xl font-bold">{selectedSection}</p>
              </div>
              <div>
                <p className="text-slate-400 text-sm mb-2">AULA ASIGNADA</p>
                <p className="text-white text-4xl font-bold text-blue-500">
                  Aula {BELONGINGS_ASSIGNMENT[selectedSection]}
                </p>
              </div>
            </div>

            <div className="bg-blue-900 bg-opacity-30 border border-blue-700 rounded-lg p-6">
              <h4 className="text-white font-bold mb-3 flex items-center gap-2">
                ℹ️ Información Importante
              </h4>
              <ul className="text-sm text-slate-300 space-y-2">
                <li>• Deja tus bultos en la Aula {BELONGINGS_ASSIGNMENT[selectedSection]} antes de las 12:10 p.m.</li>
                <li>• Los estudiantes responsables de la sección te guiarán</li>
                <li>• Recupera tus pertenencias a las 3:50 p.m. en la misma aula</li>
                <li>• No dejes objetos de valor sin supervisión</li>
              </ul>
            </div>
          </div>

          {/* Visual Representation */}
          <div className="mt-8 pt-8 border-t border-slate-700">
            <p className="text-slate-400 text-sm mb-4">UBICACIÓN DEL AULA</p>
            <div className="grid grid-cols-6 gap-2">
              {Array.from({ length: 37 }, (_, i) => {
                const aula = (i + 1).toString();
                const isSelected = aula === BELONGINGS_ASSIGNMENT[selectedSection];
                return (
                  <div
                    key={i}
                    className={`p-3 rounded text-center font-bold transition-all ${
                      isSelected
                        ? 'bg-blue-600 text-white scale-110 shadow-lg'
                        : 'bg-slate-700 text-slate-300 hover:bg-slate-600'
                    }`}
                  >
                    {aula}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* Summary Table */}
      {!selectedSection && (
        <div className="bg-slate-800 rounded-xl overflow-hidden border border-slate-700">
          <div className="bg-gradient-to-r from-blue-600 to-blue-700 px-6 py-4">
            <h3 className="text-white font-bold">Tabla de Asignación Completa</h3>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="bg-slate-900 border-b border-slate-700">
                  <th className="px-6 py-3 text-left text-slate-300 font-semibold text-sm">Sección</th>
                  <th className="px-6 py-3 text-left text-slate-300 font-semibold text-sm">Aula</th>
                </tr>
              </thead>
              <tbody>
                {filteredSections.map((section, idx) => (
                  <tr
                    key={section}
                    className={`border-b border-slate-700 hover:bg-slate-700 transition-colors ${
                      idx % 2 === 0 ? 'bg-slate-800' : 'bg-slate-750'
                    }`}
                  >
                    <td className="px-6 py-4 text-white font-semibold">{section}</td>
                    <td className="px-6 py-4">
                      <span className="bg-blue-600 text-white px-3 py-1 rounded font-bold">
                        Aula {BELONGINGS_ASSIGNMENT[section]}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
