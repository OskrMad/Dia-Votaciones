export interface PinLocation {
  id: string;
  label: string;
  icon: string;
  originalX: number;
  originalY: number;
  rainX?: number;
  rainY?: number;
  color: string;
  details?: {
    originalLocation: string;
    rainLocation: string;
    responsible: string;
    activities: string;
  };
}

export const PIN_LOCATIONS: PinLocation[] = [
  // Aulas
  {
    id: 'aula32',
    label: 'Aula 32',
    icon: '📚',
    originalX: 360,
    originalY: 340,
    color: '#3b82f6',
    details: undefined,
  },
  {
    id: 'aula33',
    label: 'Aula 33',
    icon: '📚',
    originalX: 450,
    originalY: 340,
    color: '#3b82f6',
    details: undefined,
  },
  {
    id: 'aula34',
    label: 'Aula 34',
    icon: '📚',
    originalX: 540,
    originalY: 340,
    color: '#3b82f6',
    details: undefined,
  },
  {
    id: 'aula35',
    label: 'Aula 35',
    icon: '📚',
    originalX: 630,
    originalY: 340,
    color: '#3b82f6',
    details: undefined,
  },
  {
    id: 'aula36',
    label: 'Aula 36',
    icon: '📚',
    originalX: 720,
    originalY: 340,
    color: '#3b82f6',
    details: undefined,
  },
  {
    id: 'aula37',
    label: 'Aula 37',
    icon: '📚',
    originalX: 810,
    originalY: 340,
    color: '#3b82f6',
    details: undefined,
  },
  {
    id: 'aula25',
    label: 'Aula 25',
    icon: '📚',
    originalX: 595,
    originalY: 678,
    color: '#3b82f6',
    details: undefined,
  },
  {
    id: 'aula26',
    label: 'Aula 26',
    icon: '📚',
    originalX: 515,
    originalY: 678,
    color: '#3b82f6',
    details: undefined,
  },

  // Zonas (reubicables en modo lluvia)
  {
    id: 'zona1',
    label: 'Zona 1',
    icon: '🎮',
    originalX: 420,
    originalY: 510,
    rainX: 420,
    rainY: 240, // Pasillo enfrente del Comedor
    color: '#8b5cf6',
    details: {
      originalLocation: 'Zona abierta 1',
      rainLocation: 'Pasillo enfrente del Comedor',
      responsible: 'Neidy Mairena',
      activities: 'Piedra, Papel y Salta / Captura la cola / Conteo Alternativo',
    },
  },
  {
    id: 'zona3',
    label: 'Zona 3',
    icon: '🏀',
    originalX: 600,
    originalY: 175,
    rainX: 750,
    rainY: 80, // Rampa techada de Entrada Principal
    color: '#a855f7',
    details: {
      originalLocation: 'Zona abierta 3',
      rainLocation: 'Rampa techada de la Entrada Principal',
      responsible: 'Kattia Castro, Ivannia Jara, Eduany Navarrete, Jenniffer Sequeira',
      activities: 'Marco Polo / Suelta la barra',
    },
  },
  {
    id: 'zona4',
    label: 'Zona 4',
    icon: '⚽',
    originalX: 250,
    originalY: 550,
    rainX: 500,
    rainY: 390, // Pasillo Principal Techado
    color: '#06b6d4',
    details: {
      originalLocation: 'Zona abierta 4',
      rainLocation: 'Pasillo Principal Techado de Aulas',
      responsible: 'Juan Carlos Argüello, Roberto Chacón',
      activities: 'Pulpo / Captura la bandera',
    },
  },

  // Aula Ecológica (reubicable)
  {
    id: 'aulaEco',
    label: 'Aula Ecológica',
    icon: '🌱',
    originalX: 995,
    originalY: 460,
    rainX: 850,
    rainY: 678, // Pasillo frente a la Biblioteca
    color: '#10b981',
    details: {
      originalLocation: 'Jardín / Espacio abierto de Aula Ecológica',
      rainLocation: 'Pasillo techado contiguo al Laboratorio de Cómputo (Frente a la Biblioteca)',
      responsible: 'Gabriela Vásquez',
      activities: 'Estatuas Musicales',
    },
  },

  // Entrada Principal (reubicable)
  {
    id: 'entrada',
    label: 'Entrada Principal',
    icon: '🚪',
    originalX: 720,
    originalY: 650,
    rainX: 280,
    rainY: 550, // Pasillo de Administración
    color: '#f97316',
    details: {
      originalLocation: 'Entrada Principal (Sector exterior desprotegido)',
      rainLocation: 'Pasillo de Administración (Frente a las Oficinas de Orientación y Dirección)',
      responsible: 'Elthon Agüero y Diego Chinchilla',
      activities: 'Baúl',
    },
  },

  // Otras ubicaciones (Multiusos, Comedor, etc.)
  {
    id: 'multiusos',
    label: 'Multiusos',
    icon: '💃',
    originalX: 750,
    originalY: 185,
    color: '#ec4899',
    details: undefined,
  },
  {
    id: 'comedor',
    label: 'Comedor',
    icon: '🍽️',
    originalX: 750,
    originalY: 185,
    color: '#14b8a6',
    details: undefined,
  },
  {
    id: 'gimnasio',
    label: 'Gimnasio',
    icon: '🏋️',
    originalX: 1010,
    originalY: 160,
    color: '#0ea5e9',
    details: undefined,
  },
];

export const RAIN_MODE_RELOCATIONS = {
  'Zona 1': {
    original: 'Zona abierta 1',
    rainLocation: 'Pasillo enfrente del Comedor Institucional',
    responsibles: 'Neidy Mairena',
    activities: 'Piedra, Papel y Salta / Captura la cola / Conteo Alternativo',
  },
  'Zona 3': {
    original: 'Zona abierta 3',
    rainLocation: 'Rampa techada de la Entrada Principal',
    responsibles: 'Kattia Castro, Ivannia Jara, Eduany Navarrete, Jenniffer Sequeira',
    activities: 'Marco Polo / Suelta la barra',
  },
  'Zona 4': {
    original: 'Zona abierta 4',
    rainLocation: 'Pasillo Principal Techado de Aulas',
    responsibles: 'Juan Carlos Argüello, Roberto Chacón',
    activities: 'Pulpo / Captura la bandera',
  },
  'Aula Ecológica': {
    original: 'Jardín / Espacio abierto de Aula Ecológica',
    rainLocation: 'Pasillo techado contiguo al Laboratorio de Cómputo (Frente a la Biblioteca)',
    responsibles: 'Gabriela Vásquez',
    activities: 'Estatuas Musicales',
  },
  'Entrada Principal': {
    original: 'Entrada Principal (Sector exterior desprotegido)',
    rainLocation: 'Pasillo de Administración (Frente a las Oficinas de Orientación y Dirección)',
    responsibles: 'Elthon Agüero y Diego Chinchilla',
    activities: 'Baúl',
  },
};
